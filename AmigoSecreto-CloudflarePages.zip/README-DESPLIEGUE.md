# Amigo Secreto — Despliegue en Cloudflare Pages

Esta app ya no descarga ni importa archivos: guarda cada respuesta automáticamente
en **Cloudflare KV** a través de dos endpoints (Cloudflare Pages Functions) que
viven en el mismo dominio que el sitio. No depende de sistemas externos.

## Contenido del paquete

```
index.html                          -> la aplicación (frontend)
functions/_lib/participants.js      -> directorio fijo (nombre/celular/correo) de los 16 participantes
functions/api/participants.js       -> GET /api/participants  (lista + estado de cada uno)
functions/api/response/[id].js      -> GET/POST /api/response/:id (leer y guardar la respuesta de una persona)
```

Cloudflare Pages detecta automáticamente la carpeta `functions/` y publica esas
rutas como API sin que tengas que configurar nada adicional de enrutamiento.

## Pasos para publicarlo

### 1. Crear el namespace de KV (donde se guardan las respuestas)
1. Entra al dashboard de Cloudflare → **Workers & Pages** → **KV**.
2. Crea un namespace nuevo, por ejemplo `amigo_secreto_kv`.

### 2. Crear el proyecto de Pages
1. **Workers & Pages** → **Crear aplicación** → **Pages**.
2. Sube esta carpeta completa (arrastrar y soltar) o conéctala a un repositorio Git si prefieres.
3. Framework preset: **None** (es HTML + Functions puro, no necesita build).

### 3. Enlazar el KV al proyecto
1. En el proyecto de Pages ya creado → **Settings** → **Functions** → **KV namespace bindings**.
2. Agrega un binding:
   - **Variable name**: `AMIGOS_KV`   (debe llamarse exactamente así, es el nombre que usa el código)
   - **KV namespace**: el que creaste en el paso 1.
3. Guarda y vuelve a desplegar el proyecto (Cloudflare pide un redeploy para que el binding tome efecto).

### 4. Listo
Abre la URL que te da Cloudflare Pages (ej. `https://amigo-secreto.pages.dev`) desde cualquier
computador o celular. Todo el mundo verá los mismos datos en tiempo real porque quedan guardados
en KV, no en el navegador de cada quien.

## Cómo funciona la app ahora

- **Mis preferencias**: cada participante elige su nombre, escribe 3 endulzadas, 3 ideas de
  regalo y observaciones, y presiona "Guardar". Esto llama a `POST /api/response/:id`, que
  guarda el registro en KV al instante.
- **Buscar amigo secreto**: como el sorteo ya está hecho fuera de la app y cada persona ya sabe
  a quién le regala, aquí simplemente se selecciona el nombre de esa persona y se consulta
  `GET /api/response/:id` para mostrar sus endulzadas y opciones de regalo (o un aviso si aún
  no ha respondido).
- **Directorio**: muestra el contacto de los 16 participantes y si ya completaron sus preferencias,
  usando `GET /api/participants`.

## Notas importantes

- El directorio de participantes (nombre, celular, correo) está fijo en
  `functions/_lib/participants.js`. Si alguien cambia de celular/correo o hay que agregar/quitar
  a alguien, se edita ese archivo y se vuelve a desplegar.
- No hay ninguna lógica de sorteo dentro de la app: no se generan ni se muestran las parejas.
  Cada quien debe ya saber a quién le regala (por el sorteo que hicieron fuera de esta herramienta).
- Los datos quedan en tu cuenta de Cloudflare (KV), tal como lo pediste.
